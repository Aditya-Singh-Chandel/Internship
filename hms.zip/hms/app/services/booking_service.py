from app.utils.validation_utils import (
    validate_room_belongs_to_room_type,
    validate_room_type_availability,
    validate_assigned_rooms_not_overlapping,
    validate_string
)
from app.utils.query_utils import extract_filters, apply_filters, apply_sorting, filter_active, OPERATOR_MAP
from datetime import date, datetime, timezone
from decimal import Decimal
from fastapi import HTTPException
import uuid
from sqlalchemy import extract
from sqlalchemy.orm import Session, joinedload
from app.models.booking import Booking
from app.models.booking_item import BookingItem
from app.models.hotel import Hotel
from app.models.room_type import RoomType
from app.models.guest import Guest
from app.models.booking_guest import BookingGuest
from app.models.booking_room import BookingRoom
from app.schemas.booking import BookingCreate, BookingUpdate

def create_booking(db: Session, booking: BookingCreate):
    _data_dict = booking.model_dump()
    items_data = _data_dict.pop("items", [])

    if not items_data:
        raise HTTPException(status_code=400, detail="At least one room type item must be selected for the booking.")

    if _data_dict["checkin_date"] >= _data_dict["checkout_date"]:
        raise HTTPException(status_code=400, detail="checkout_date must be after checkin_date.")
    if _data_dict["checkin_date"] < date.today():
        raise HTTPException(status_code=400, detail="checkin_date must be today or in the future.")

    # Validate hotel exists and is active
    hotel = db.query(Hotel).filter(Hotel.id == _data_dict["hotel_id"], Hotel.is_deleted == False).first()
    if not hotel:
        raise HTTPException(status_code=404, detail="The specified hotel does not exist.")

    # Validate primary booker exists and is active
    guest = db.query(Guest).filter(Guest.id == _data_dict["guest_id"], Guest.is_deleted == False).first()
    if not guest:
        raise HTTPException(status_code=404, detail="The specified guest does not exist.")

    nights = max(1, (_data_dict["checkout_date"] - _data_dict["checkin_date"]).days)
    calculated_total = Decimal("0.00")
    db_items = []

    # Validate each line item room type availability and calculate rates
    for line in items_data:
        if line["quantity"] < 1:
            raise HTTPException(status_code=400, detail="Quantity for each room type must be at least 1.")

        rt = db.query(RoomType).filter(RoomType.id == line["room_type_id"], RoomType.is_deleted == False).first()
        if not rt:
            raise HTTPException(status_code=404, detail=f"Room type {line['room_type_id']} does not exist.")
        if str(rt.hotel_id) != str(_data_dict["hotel_id"]):
            raise HTTPException(status_code=400, detail=f"Room type '{rt.name}' does not belong to the selected hotel.")

        validate_room_type_availability(
            db=db,
            room_type_id=rt.id,
            checkin_date=_data_dict["checkin_date"],
            checkout_date=_data_dict["checkout_date"],
            requested_rooms=line["quantity"]
        )

        unit_price = Decimal(line["unit_price"]) if line.get("unit_price") is not None else Decimal(rt.base_price)
        calculated_total += unit_price * Decimal(line["quantity"]) * Decimal(nights)

        db_items.append(BookingItem(
            room_type_id=rt.id,
            quantity=line["quantity"],
            unit_price=unit_price
        ))

    # Clean text inputs
    for k, v in _data_dict.items():
        if isinstance(v, str):
            _data_dict[k] = validate_string(k, v)

    if _data_dict.get("total_amount") is None:
        _data_dict["total_amount"] = calculated_total

    db_booking = Booking(**_data_dict)
    db_booking.booking_items = db_items

    db.add(db_booking)
    db.commit()
    db.refresh(db_booking)
    return db_booking

def get_bookings(db: Session, query_params: dict | None = None):
    if query_params is None:
        query_params = {}

    month = query_params.get("month")
    month_op = query_params.get("month_op")
    if hasattr(month_op, "value"): month_op = month_op.value
    month_op = month_op or "eq"

    year = query_params.get("year")
    year_op = query_params.get("year_op")
    if hasattr(year_op, "value"): year_op = year_op.value
    year_op = year_op or "eq"

    if month and not year:
        raise HTTPException(status_code=400, detail="year is required when month is provided")
    if year and not month:
        raise HTTPException(status_code=400, detail="month is required when year is provided")

    rooms_count = query_params.get("rooms_count")
    rooms_count_op = query_params.get("rooms_count_op")
    if hasattr(rooms_count_op, "value"): rooms_count_op = rooms_count_op.value
    rooms_count_op = rooms_count_op or "eq"

    parsed = extract_filters(query_params, extra_reserved={"month", "year", "month_op", "year_op", "rooms_count", "rooms_count_op"})

    query = db.query(Booking).options(
        joinedload(Booking.booking_items).joinedload(BookingItem.booking_rooms)
    )
    query = filter_active(query, Booking, query_params)

    # Apply month/year filter on checkin_date
    if month and year:
        op_func_month = OPERATOR_MAP[month_op]
        op_func_year = OPERATOR_MAP[year_op]
        query = query.filter(
            op_func_month(extract("month", Booking.checkin_date), month),
            op_func_year(extract("year", Booking.checkin_date), year),
        )

    query = apply_filters(query, Booking, parsed["filters"])
    query = apply_sorting(query, Booking, parsed["sort_by"], parsed["sort_order"])
    items = query.all()

    if rooms_count is not None:
        op_func = OPERATOR_MAP.get(rooms_count_op, OPERATOR_MAP["eq"])
        items = [b for b in items if op_func(sum(bi.quantity for bi in b.booking_items if not bi.is_deleted), rooms_count)]

    return {"bookings": items}

def get_booking_by_id(db: Session, item_id: uuid.UUID):
    item = db.query(Booking).options(
        joinedload(Booking.booking_items).joinedload(BookingItem.booking_rooms)
    ).filter(Booking.id == item_id, Booking.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Booking is not present.")
    return item

def update_booking(db: Session, item_id: uuid.UUID, update_data: BookingUpdate):
    item = db.query(Booking).filter(Booking.id == item_id, Booking.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Booking is not present.")

    update_data_dict = update_data.model_dump(exclude_unset=True)

    if "hotel_id" in update_data_dict and update_data_dict["hotel_id"] != item.hotel_id:
        active_rooms = [r for bi in item.booking_items if not bi.is_deleted for r in bi.booking_rooms if not r.is_deleted]
        if active_rooms:
            raise HTTPException(
                status_code=400,
                detail="Cannot change hotel_id for a booking that already has allocated rooms."
            )
        hotel = db.query(Hotel).filter(Hotel.id == update_data_dict["hotel_id"], Hotel.is_deleted == False).first()
        if not hotel:
            raise HTTPException(status_code=404, detail="The specified hotel does not exist.")

    if "guest_id" in update_data_dict:
        guest = db.query(Guest).filter(Guest.id == update_data_dict["guest_id"], Guest.is_deleted == False).first()
        if not guest:
            raise HTTPException(status_code=404, detail="The specified guest does not exist.")

    for key, value in update_data_dict.items():
        setattr(item, key, value)

    if item.checkin_date >= item.checkout_date:
        raise HTTPException(status_code=400, detail="checkout_date must be after checkin_date.")

    # Validate room types availability if dates changed on an active reservation
    if item.status not in ["cancelled", "completed"] and item.booking_items:
        for b_item in item.booking_items:
            if not b_item.is_deleted:
                validate_room_type_availability(
                    db,
                    b_item.room_type_id,
                    item.checkin_date,
                    item.checkout_date,
                    exclude_booking_id=item.id,
                    requested_rooms=b_item.quantity
                )

    db.commit()
    db.refresh(item)
    return item

def delete_booking(db: Session, item_id: uuid.UUID):
    item = db.query(Booking).filter(Booking.id == item_id, Booking.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Booking is not present.")

    now = datetime.now(timezone.utc)
    item.is_deleted = True
    item.deleted_at = now

    # Cascade soft-delete to booking_items
    db.query(BookingItem).filter(BookingItem.booking_id == item.id, BookingItem.is_deleted == False).update({
        BookingItem.is_deleted: True,
        BookingItem.deleted_at: now
    })

    # Cascade soft-delete to booking_rooms
    for b_item in item.booking_items:
        db.query(BookingRoom).filter(BookingRoom.booking_item_id == b_item.id, BookingRoom.is_deleted == False).update({
            BookingRoom.is_deleted: True,
            BookingRoom.deleted_at: now
        })

    # Cascade soft-delete to booking_guests
    db.query(BookingGuest).filter(BookingGuest.booking_id == item.id, BookingGuest.is_deleted == False).update({
        BookingGuest.is_deleted: True,
        BookingGuest.deleted_at: now
    })

    db.commit()
    db.refresh(item)
    return item