from app.utils.validation_utils import (
    validate_string, validate_future_date, validate_media_linkage
)
from app.utils.query_utils import extract_filters, apply_filters, apply_sorting, filter_active
from datetime import date, datetime, timezone
from fastapi import HTTPException
import uuid
from sqlalchemy.orm import Session
from app.models.media import Media
from app.schemas.media import MediaCreate


def create_media(db: Session, media: MediaCreate):
    _data_dict = media.model_dump()
    for k, v in _data_dict.items():
        if isinstance(v, str): _data_dict[k] = validate_string(k, v)
        elif isinstance(v, date) and k in ["checkin_date", "checkout_date"]: _data_dict[k] = validate_future_date(k, v)

    # Validate foreign keys: either one is set, or if both are set, they must link to the same hotel
    validate_media_linkage(db, _data_dict.get("hotel_id"), _data_dict.get("room_type_id"))

    # If marking as primary, ensure only one primary media exists in that entity scope
    if _data_dict.get("is_primary"):
        if _data_dict.get("room_type_id"):
            db.query(Media).filter(
                Media.room_type_id == _data_dict["room_type_id"],
                Media.is_deleted == False
            ).update({"is_primary": False})
        elif _data_dict.get("hotel_id"):
            db.query(Media).filter(
                Media.hotel_id == _data_dict["hotel_id"],
                Media.room_type_id == None,
                Media.is_deleted == False
            ).update({"is_primary": False})

    db_media = Media(**_data_dict)
    db.add(db_media)
    db.commit()
    db.refresh(db_media)
    return db_media

def get_media(db: Session, query_params: dict | None = None):
    if query_params is None:
        query_params = {}

    parsed = extract_filters(query_params)

    query = db.query(Media)
    query = filter_active(query, Media, query_params)
    query = apply_filters(query, Media, parsed["filters"])
    query = apply_sorting(query, Media, parsed["sort_by"], parsed["sort_order"])
    items = query.all()

    return {"media": items}

def get_media_by_id(db: Session, item_id: uuid.UUID):
    item = db.query(Media).filter(Media.id == item_id, Media.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Media is not present.")
    return item

def update_media(db: Session, item_id: uuid.UUID, update_data):
    item = db.query(Media).filter(Media.id == item_id, Media.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Media is not present.")

    update_data_dict = update_data.model_dump(exclude_unset=True)

    # Validate foreign keys linkage on effective values
    effective_hotel_id = update_data_dict.get("hotel_id", item.hotel_id)
    effective_room_type_id = update_data_dict.get("room_type_id", item.room_type_id)
    validate_media_linkage(db, effective_hotel_id, effective_room_type_id)

    # If updating is_primary to True, un-set existing primary in that scope
    if update_data_dict.get("is_primary"):
        if effective_room_type_id:
            db.query(Media).filter(
                Media.room_type_id == effective_room_type_id,
                Media.id != item.id,
                Media.is_deleted == False
            ).update({"is_primary": False})
        elif effective_hotel_id:
            db.query(Media).filter(
                Media.hotel_id == effective_hotel_id,
                Media.room_type_id == None,
                Media.id != item.id,
                Media.is_deleted == False
            ).update({"is_primary": False})

    for key, value in update_data_dict.items():
        if isinstance(value, str):
            value = validate_string(key, value)
        elif isinstance(value, date) and key in ["checkin_date", "checkout_date"]:
            value = validate_future_date(key, value)
        setattr(item, key, value)

    db.commit()
    db.refresh(item)
    return item

def delete_media(db: Session, item_id: uuid.UUID):
    item = db.query(Media).filter(Media.id == item_id, Media.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Media is not present.")

    now = datetime.now(timezone.utc)
    item.is_deleted = True
    item.deleted_at = now
    db.commit()
    db.refresh(item)
    return item
