from app.utils.validation_utils import validate_string, validate_future_date, validate_room_number_unique_in_hotel
from app.utils.query_utils import extract_filters, apply_filters, apply_sorting, filter_active
from datetime import date, datetime, timezone
from fastapi import HTTPException
import uuid
from sqlalchemy.orm import Session
from app.models.room import Room
from app.models.booking import Booking
from app.schemas.room import RoomCreate


def create_room(db: Session, room: RoomCreate):
    _data_dict = room.model_dump()
    for k, v in _data_dict.items():
        if isinstance(v, str): _data_dict[k] = validate_string(k, v)
        elif isinstance(v, date) and k in ["checkin_date", "checkout_date"]: _data_dict[k] = validate_future_date(k, v)

    # Room number must be unique across all physical rooms in the same hotel
    validate_room_number_unique_in_hotel(db, _data_dict["room_type_id"], _data_dict["room_number"])

    db_room = Room(**_data_dict)
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    return db_room

def get_rooms(db: Session, query_params: dict | None = None):
    if query_params is None:
        query_params = {}

    parsed = extract_filters(query_params)

    query = db.query(Room)
    query = filter_active(query, Room, query_params)
    query = apply_filters(query, Room, parsed["filters"])
    query = apply_sorting(query, Room, parsed["sort_by"], parsed["sort_order"])
    items = query.all()

    return {"rooms": items}

def get_room_by_id(db: Session, item_id: uuid.UUID):
    item = db.query(Room).filter(Room.id == item_id, Room.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Room is not present.")
    return item

def update_room(db: Session, item_id: uuid.UUID, update_data):
    item = db.query(Room).filter(Room.id == item_id, Room.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Room is not present.")

    update_data_dict = update_data.model_dump(exclude_unset=True)

    effective_room_type_id = update_data_dict.get("room_type_id", item.room_type_id)
    effective_room_number = update_data_dict.get("room_number", item.room_number)
    validate_room_number_unique_in_hotel(db, effective_room_type_id, effective_room_number, exclude_room_id=item.id)

    for key, value in update_data_dict.items():
        if isinstance(value, str):
            value = validate_string(key, value)
        elif isinstance(value, date) and key in ["checkin_date", "checkout_date"]:
            value = validate_future_date(key, value)
        setattr(item, key, value)

    db.commit()
    db.refresh(item)
    return item

def delete_room(db: Session, item_id: uuid.UUID):
    item = db.query(Room).filter(Room.id == item_id, Room.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Room is not present.")

    now = datetime.now(timezone.utc)
    item.is_deleted = True
    item.deleted_at = now

    # Deletion Safeguard: Safely unassign this physical room from any active upcoming booking rooms
    from app.models.booking_room import BookingRoom
    db.query(BookingRoom).filter(
        BookingRoom.room_id == item.id,
        BookingRoom.is_deleted == False,
        BookingRoom.status.notin_(["cancelled", "checked_out"])
    ).update({BookingRoom.room_id: None})

    db.commit()
    db.refresh(item)
    return item
