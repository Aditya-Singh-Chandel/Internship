import uuid
from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.models.booking_item import BookingItem
from app.utils.query_utils import extract_filters, apply_filters, apply_sorting, filter_active

def get_booking_items(db: Session, query_params: dict | None = None):
    if query_params is None:
        query_params = {}

    parsed = extract_filters(query_params)
    query = db.query(BookingItem)
    query = filter_active(query, BookingItem, query_params)
    query = apply_filters(query, BookingItem, parsed["filters"])
    query = apply_sorting(query, BookingItem, parsed["sort_by"], parsed["sort_order"])
    items = query.all()
    return {"booking_items": items}

def get_booking_item_by_id(db: Session, item_id: uuid.UUID):
    item = db.query(BookingItem).filter(BookingItem.id == item_id, BookingItem.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This BookingItem is not present.")
    return item
