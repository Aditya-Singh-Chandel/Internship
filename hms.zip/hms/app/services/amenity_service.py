from app.utils.validation_utils import validate_string, validate_future_date, validate_amenity_linkage
from app.utils.query_utils import extract_filters, apply_filters, apply_sorting, filter_active
from datetime import date, datetime, timezone
from fastapi import HTTPException
import uuid
from sqlalchemy.orm import Session
from app.models.amenity import Amenity
from app.schemas.amenity import AmenityCreate


def create_amenity(db: Session, amenity: AmenityCreate):
    _data_dict = amenity.model_dump()
    for k, v in _data_dict.items():
        if isinstance(v, str): _data_dict[k] = validate_string(k, v)
        elif isinstance(v, date) and k in ["checkin_date", "checkout_date"]: _data_dict[k] = validate_future_date(k, v)

    # Validate cross-reference linkage between hotel and room_type
    validate_amenity_linkage(db, _data_dict.get("hotel_id"), _data_dict.get("room_type_id"))

    db_amenity = Amenity(**_data_dict)
    db.add(db_amenity)
    db.commit()
    db.refresh(db_amenity)
    return db_amenity

def get_amenities(db: Session, query_params: dict | None = None):
    if query_params is None:
        query_params = {}

    parsed = extract_filters(query_params)

    query = db.query(Amenity)
    query = filter_active(query, Amenity, query_params)
    query = apply_filters(query, Amenity, parsed["filters"])
    query = apply_sorting(query, Amenity, parsed["sort_by"], parsed["sort_order"])
    items = query.all()

    return {"amenities": items}

def get_amenity_by_id(db: Session, item_id: uuid.UUID):
    item = db.query(Amenity).filter(Amenity.id == item_id, Amenity.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Amenity is not present.")
    return item

def update_amenity(db: Session, item_id: uuid.UUID, update_data):
    item = db.query(Amenity).filter(Amenity.id == item_id, Amenity.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Amenity is not present.")

    update_data_dict = update_data.model_dump(exclude_unset=True)

    effective_hotel_id = update_data_dict.get("hotel_id", item.hotel_id)
    effective_room_type_id = update_data_dict.get("room_type_id", item.room_type_id)
    validate_amenity_linkage(db, effective_hotel_id, effective_room_type_id)

    for key, value in update_data_dict.items():
        if isinstance(value, str):
            value = validate_string(key, value)
        elif isinstance(value, date) and key in ["checkin_date", "checkout_date"]:
            value = validate_future_date(key, value)
        setattr(item, key, value)

    db.commit()
    db.refresh(item)
    return item

def delete_amenity(db: Session, item_id: uuid.UUID):
    item = db.query(Amenity).filter(Amenity.id == item_id, Amenity.is_deleted == False).first()
    if not item:
        raise HTTPException(status_code=404, detail="This Amenity is not present.")

    now = datetime.now(timezone.utc)
    item.is_deleted = True
    item.deleted_at = now
    db.commit()
    db.refresh(item)
    return item
