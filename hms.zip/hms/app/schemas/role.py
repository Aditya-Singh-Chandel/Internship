from pydantic import BaseModel, Field
from uuid import UUID

class RoleBase(BaseModel):
    name: str = Field(description="Letters, numbers, special characters, and spaces. Cannot be exclusively numbers or special characters. Max 255 chars after trimming.", examples=[""])

class RoleCreate(RoleBase):
    pass

from datetime import datetime

class RoleItem(RoleBase):
    id: UUID
    is_deleted: bool = False
    deleted_at: datetime | None = None


class RoleUpdate(BaseModel):
    name: str | None = Field(default=None, description="Letters, numbers, special characters, and spaces. Cannot be exclusively numbers or special characters. Max 255 chars after trimming.", examples=[""])

class RoleListResponse(BaseModel):
    roles: list[RoleItem]
