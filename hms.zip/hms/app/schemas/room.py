from pydantic import BaseModel, Field, field_validator
from uuid import UUID
from enum import Enum

class RoomStatus(str, Enum):
    available = "available"
    occupied = "occupied"
    maintenance = "maintenance"
    cleaned = "cleaned"

class RoomBase(BaseModel):
    room_type_id: UUID = Field(description="Valid value for room type id.", examples=[""])
    room_number: str = Field(description="Assigned room number or identifier.", examples=[""])
    floor: int | None = Field(default=None, ge=-10, le=200, description="Floor number as an integer.", examples=[1])
    status: RoomStatus | None = Field(default=RoomStatus.available, description="Current status (e.g., active, completed, confirmed).", examples=[""])

    @field_validator("floor", mode="before")
    @classmethod
    def validate_floor_empty(cls, v):
        if v == "" or v is None:
            return None
        return v

class RoomCreate(RoomBase):
    pass

from datetime import datetime

class RoomItem(RoomBase):
    id: UUID
    is_deleted: bool = False
    deleted_at: datetime | None = None


class RoomUpdate(BaseModel):
    room_type_id: UUID | None = Field(default=None, description="Valid value for room type id.", examples=[""])
    room_number: str | None = Field(default=None, description="Assigned room number or identifier.", examples=[""])
    floor: int | None = Field(default=None, ge=-10, le=200, description="Floor number as an integer.", examples=[1])
    status: RoomStatus | None = Field(default=None, description="Current status (e.g., active, completed, confirmed).", examples=[""])

    @field_validator("floor", mode="before")
    @classmethod
    def validate_floor_empty(cls, v):
        if v == "" or v is None:
            return None
        return v

class RoomListResponse(BaseModel):
    rooms: list[RoomItem]
