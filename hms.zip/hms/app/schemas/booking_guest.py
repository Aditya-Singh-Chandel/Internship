from pydantic import BaseModel, Field
from uuid import UUID

class BookingGuestBase(BaseModel):
    booking_id: UUID = Field(description="Valid value for booking id.", examples=[""])
    guest_id: UUID = Field(description="Valid value for guest id.", examples=[""])
    booking_room_id: UUID | None = Field(default=None, description="Optional room assignment for this companion.")

class BookingGuestCreate(BookingGuestBase):
    pass

from datetime import datetime

class BookingGuestItem(BookingGuestBase):
    id: UUID
    is_deleted: bool = False
    deleted_at: datetime | None = None


class BookingGuestUpdate(BaseModel):
    booking_id: UUID | None = Field(default=None, description="Valid value for booking id.", examples=[""])
    guest_id: UUID | None = Field(default=None, description="Valid value for guest id.", examples=[""])
    booking_room_id: UUID | None = Field(default=None, description="Optional room assignment for this companion.")

class BookingGuestListResponse(BaseModel):
    booking_guests: list[BookingGuestItem]
