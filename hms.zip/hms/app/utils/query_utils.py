from sqlalchemy import asc, desc


# ---------------------------------------------------------------------------
# Operator definitions
# ---------------------------------------------------------------------------

OPERATOR_MAP = {
    "eq":   lambda col, val: col == val,
    "lt":   lambda col, val: col < val,
    "gt":   lambda col, val: col > val,
    "lte":  lambda col, val: col <= val,
    "gte":  lambda col, val: col >= val,
    "like": lambda col, val: col.ilike(f"%{val}%"),
}


# ---------------------------------------------------------------------------
# Reserved parameter keys (excluded from filter extraction)
# --------------------------------------------------------------------------

BASE_RESERVED = {"sort_by", "sort_order", "include_deleted"}


def filter_active(query, model, query_params: dict | None = None):
    """
    Filter out soft-deleted records (is_deleted == False),
    unless the caller explicitly specified 'is_deleted' or 'include_deleted' in query_params.
    """
    if hasattr(model, "is_deleted"):
        if query_params:
            if "is_deleted" in query_params:
                return query
            if str(query_params.get("include_deleted", "")).lower() in ("true", "1"):
                return query
        return query.filter(model.is_deleted == False)
    return query


# ---------------------------------------------------------------------------
# Extract pre-validated filters from query params
# ---------------------------------------------------------------------------

def extract_filters(query_params: dict, extra_reserved: set | None = None):
    """
    Convert query params into structured filter/sort dicts.
    Pairs fields with their corresponding operator keys (e.g., 'price' with 'price_op').

    Args:
        query_params:    dict of already-typed query values (from locals())
        extra_reserved:  additional param keys to skip (e.g. "month", "year")

    Returns:
        dict with keys: filters, sort_by, sort_order
    """
    reserved = BASE_RESERVED | (extra_reserved or set())

    filters = []

    for key, value in query_params.items():
        if key in reserved or key.endswith("_op"):
            continue

        op_key = f"{key}_op"
        op = query_params.get(op_key, "eq")
        # Enum values -> plain string
        op = op.value if hasattr(op, "value") else op

        filters.append({"field": key, "op": op, "value": value})

    # Enum values -> plain string for sort fields too
    sort_by = query_params.get("sort_by")
    if sort_by and hasattr(sort_by, "value"):
        sort_by = sort_by.value

    sort_order = query_params.get("sort_order", "asc")
    if hasattr(sort_order, "value"):
        sort_order = sort_order.value

    return {
        "filters": filters,
        "sort_by": sort_by,
        "sort_order": sort_order,
    }


# ---------------------------------------------------------------------------
# Query application helpers
# ---------------------------------------------------------------------------

def apply_filters(query, model, filters: list):
    """Apply a list of validated filter dicts to a SQLAlchemy query."""
    for f in filters:
        column = getattr(model, f["field"])
        op_func = OPERATOR_MAP[f["op"]]
        query = query.filter(op_func(column, f["value"]))
    return query


def apply_sorting(query, model, sort_by: str | None, sort_order: str = "asc"):
    """Apply ORDER BY to a SQLAlchemy query."""
    if sort_by:
        column = getattr(model, sort_by)
        query = query.order_by(
            desc(column) if sort_order == "desc" else asc(column)
        )
    return query
